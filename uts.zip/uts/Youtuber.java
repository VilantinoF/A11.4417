public class Youtuber extends Gamer {
    int subscriber, viewer;

    public void ShowSubAndView() {
        System.out.println(subscriber);
        System.out.println(viewer);
    }

}