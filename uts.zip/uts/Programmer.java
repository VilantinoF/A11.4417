public class Programmer extends Gamer {
    public void Play() {
        for (int i = 0; i < super.jenisGame.size(); i++) {
            int rand = (int) (Math.random() * super.jenisGame.size()) + 1;
            System.out.println(super.getNama() + " is winning on " + rand);
        }
    }
}